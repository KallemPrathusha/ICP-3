#Author: Prathusha kallem
class Employee:
    count = 0
    salary_cnt = 0
    def __init__(self, name, family, salary, department):
        self.name = name
        self.family = family
        self.salary = salary
        self.department = department
        Employee.count += 1
        Employee.salary_cnt = Employee.salary_cnt + salary

    def average_salary(self):
        return Employee.salary_cnt/Employee.count
class FulltimeEmployee(Employee):
    pass


fulltime_employee1 = FulltimeEmployee("Prathusha", "Kallem", 934254, "HR")
fulltime_employee2 = FulltimeEmployee("Nandhan", "Valluri", 800000, "Programmer")
print("Fulltime Employees average salary using member function: {}".format(
    fulltime_employee2.average_salary()))
employee1 = Employee("Teja", "Miryala", 65300, "CS")
employee2 = Employee("Harsha", "Bathula", 77000, "IT")
print("Employees average salary using member function: {}".format(
    employee1.average_salary()))
